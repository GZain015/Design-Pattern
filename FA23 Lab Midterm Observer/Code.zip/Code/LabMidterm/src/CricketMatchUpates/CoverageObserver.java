/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CricketMatchUpates;

/**
 *
 * @author Zain
 */
public abstract class CoverageObserver {
    protected Cricket_Match1 match1;
    protected Cricket_Match2 match2;
    public abstract void update();
}
